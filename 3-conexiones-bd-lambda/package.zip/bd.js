const AWS = require('aws-sdk');
const mysql = require('mysql2/promise');

const secretsManager = new AWS.SecretsManager();

let pool;

async function getPool() {
    if (!pool) {
        const secretData = await secretsManager.getSecretValue({ SecretId: 'secrectMaster' }).promise();
        const secret = JSON.parse(secretData.SecretString);

        pool = mysql.createPool({
            host: secret.host,
            user: secret.username,
            password: secret.password,
            database: 'master',
            port: secret.port,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });
    }
    return pool;
}

async function getAllProducts() {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT * FROM product');
    return rows;
}

async function getTotalSalesByProduct() {
    const pool = await getPool();
    const [rows] = await pool.query(`
        SELECT p.id, p.name, SUM(s.quantity) AS total_sales
        FROM product p
        JOIN sale s ON p.id = s.product_id
        GROUP BY p.id, p.name
    `);
    return rows;
}

async function getProductWithHighestPrice() {
    const pool = await getPool();
    const [rows] = await pool.query(`
        SELECT p.id, p.name, MAX(s.price) AS highest_price
        FROM product p
        JOIN sale s ON p.id = s.product_id
        GROUP BY p.id, p.name
        ORDER BY highest_price DESC
        LIMIT 1
    `);
    return rows[0];
}

module.exports = {
    getAllProducts,
    getTotalSalesByProduct,
    getProductWithHighestPrice
};
